import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'cms_parser.dart';
import 'models.dart';
/// Persistent preferences and backup serializer compatible with Android `Prefs.java`.
class StorageService {
  static const String keyOrigin = 'origin';
  static const String keyRawConfig = 'config_raw_json';
  static const String keySelectedSite = 'selected_site';
  static const String keyWatchHistory = 'watch_history';
  static const String keyFavorites = 'favorites';
  static const String keySearchHistory = 'global_search_history';
  static const String keyEpisodesDescending = 'episodes_descending';
  static const String keyPlaySpeed = 'play_speed';
  static const String keyAutoNext = 'auto_next';
  static const String keySkipIntroSec = 'skip_intro_sec';
  static const String keySkipOutroSec = 'skip_outro_sec';
  static const String keyRepeatMode = 'repeat_mode';
  static const String keyQuarkCookie = 'netdisk_quark_cookie';
  static const String keyUcCookie = 'netdisk_uc_cookie';
  static const String keyBaiduCookie = 'netdisk_baidu_cookie';
  static const String keyAliToken = 'netdisk_ali_token';
  static const String keyDriveOrder = 'netdisk_drive_order';
  static const String keyDepots = 'saved_depots';
  static const String keyActiveDepotName = 'active_depot_name';
  static const String keySubscriptions = 'saved_subscriptions';
  static const String keyPrivacyPassword = 'privacy_password';
  final SharedPreferences _prefs;
  StorageService(this._prefs);
  static Future<StorageService> init() async {
    final prefs = await SharedPreferences.getInstance();
    return StorageService(prefs);
  }
  String get configOrigin => _prefs.getString(keyOrigin) ?? '';
  String get rawConfig => _prefs.getString(keyRawConfig) ?? '';
  String get selectedSiteKey => _prefs.getString(keySelectedSite) ?? '';
  String get activeDepotName => _prefs.getString(keyActiveDepotName) ?? '';
  bool get episodesDescending => _prefs.getBool(keyEpisodesDescending) ?? false;
  double get playSpeed =>
      (_prefs.getDouble(keyPlaySpeed) ?? 1.0).clamp(0.5, 2.0);
  bool get autoNext => _prefs.getBool(keyAutoNext) ?? true;
  int get skipIntroSec => (_prefs.getInt(keySkipIntroSec) ?? 0).clamp(0, 600);
  int get skipOutroSec => (_prefs.getInt(keySkipOutroSec) ?? 0).clamp(0, 600);
  String get repeatMode => _prefs.getString(keyRepeatMode) ?? 'off';
  String get quarkCookie => _prefs.getString(keyQuarkCookie) ?? '';
  String get ucCookie => _prefs.getString(keyUcCookie) ?? '';
  String get baiduCookie => _prefs.getString(keyBaiduCookie) ?? '';
  String get aliToken => _prefs.getString(keyAliToken) ?? '';
  List<String> get driveOrder {
    const defaults = ['quark', 'uc', 'baidu', 'ali'];
    final raw = _prefs.getStringList(keyDriveOrder);
    if (raw == null || raw.isEmpty) return defaults;
    final out = <String>[
      for (final d in raw)
        if (defaults.contains(d)) d,
    ];
    for (final d in defaults) {
      if (!out.contains(d)) out.add(d);
    }
    return out;
  }
  List<CmsDepot> getSavedDepots() {
    final raw = _prefs.getString(keyDepots) ?? '[]';
    try {
      final list = jsonDecode(raw);
      if (list is! List) return const [];
      return list
          .whereType<Map>()
          .map((m) => CmsDepot.fromJson(Map<String, dynamic>.from(m)))
          .where((d) => d.url.isNotEmpty)
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }
  String get privacyPassword => _prefs.getString(keyPrivacyPassword) ?? '';
  bool get hasPrivacyPassword => privacyPassword.trim().isNotEmpty;
  bool verifyPrivacyPassword(String input) =>
      hasPrivacyPassword && input.trim() == privacyPassword.trim();
  Future<void> setPrivacyPassword(String password) async {
    await _prefs.setString(keyPrivacyPassword, password.trim());
  }

  List<SubscriptionEntry> getSubscriptions() {
    final raw = _prefs.getString(keySubscriptions) ?? '[]';
    try {
      final list = jsonDecode(raw);
      if (list is! List) return const [];
      return list
          .whereType<Map>()
          .map((m) => SubscriptionEntry.fromJson(Map<String, dynamic>.from(m)))
          .where((s) => s.id.isNotEmpty)
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }

  List<String> getSubscriptionGroups({bool includePrivate = false}) {
    final groups = <String>['默认分组'];
    for (final s in getSubscriptions()) {
      if (!includePrivate && s.isPrivate) continue;
      final g = s.group.trim();
      if (g.isNotEmpty && !groups.contains(g)) {
        groups.add(g);
      }
    }
    return groups;
  }

  Future<void> saveSubscriptions(List<SubscriptionEntry> subs) async {
    await _prefs.setString(
      keySubscriptions,
      jsonEncode(subs.map((s) => s.toJson()).toList()),
    );
  }

  Future<CmsConfig?> upsertSubscriptions(
    List<SubscriptionEntry> incoming, {
    List<CmsDepot>? depots,
    String? activeDepotName,
  }) async {
    if (incoming.isEmpty) return loadSavedConfig();
    final current = getSubscriptions().toList();
    // Migrate legacy single config into subscriptions list if not yet present
    if (current.isEmpty && rawConfig.trim().isNotEmpty) {
      try {
        final legacyParsed = CmsParser.parseConfig(
          rawConfig,
          origin: configOrigin,
        );
        final fmt = CmsParser.detectSubscriptionFormat(
          rawConfig,
          origin: configOrigin,
        );
        current.add(
          SubscriptionEntry(
            id: 'legacy_primary',
            name: this.activeDepotName.isNotEmpty
                ? this.activeDepotName
                : (configOrigin.isNotEmpty
                    ? (Uri.tryParse(configOrigin)?.host ?? '默认仓库')
                    : '默认配置'),
            url: configOrigin,
            group: '默认分组',
            format: legacyParsed.depots.isNotEmpty ? '多仓' : fmt,
            isPrivate: false,
            enabled: true,
            rawContent: rawConfig,
            siteCount: legacyParsed.supportedSites.length,
            liveCount: legacyParsed.lives.length,
            updatedAt: DateTime.now().millisecondsSinceEpoch - 1000,
          ),
        );
      } catch (_) {}
    }

    for (final entry in incoming) {
      final existingIdx = current.indexWhere(
        (s) =>
            s.id == entry.id ||
            (entry.url.isNotEmpty && s.url == entry.url && s.group == entry.group),
      );
      if (existingIdx >= 0) {
        current[existingIdx] = entry.copyWith(id: current[existingIdx].id);
      } else {
        current.add(entry);
      }
    }
    await saveSubscriptions(current);

    final primary = incoming.first;
    if (primary.rawContent.isNotEmpty && !primary.isPrivate) {
      await _prefs.setString(keyRawConfig, primary.rawContent);
      await _prefs.setString(keyOrigin, primary.url);
    }
    if (depots != null && depots.isNotEmpty) {
      await _prefs.setString(
        keyDepots,
        jsonEncode(depots.map((d) => d.toJson()).toList()),
      );
    }
    if (activeDepotName != null) {
      await _prefs.setString(keyActiveDepotName, activeDepotName);
    }
    final merged = loadSavedConfig();
    if (merged != null &&
        merged.publicSupportedSites.isNotEmpty &&
        !merged.supportedSites.any((s) => s.key == selectedSiteKey)) {
      await _prefs.setString(
        keySelectedSite,
        merged.publicSupportedSites.first.key,
      );
    }
    return merged;
  }

  Future<CmsConfig?> removeSubscription(String id) async {
    final next = getSubscriptions().where((s) => s.id != id).toList();
    await saveSubscriptions(next);
    if (next.isEmpty) {
      await _prefs.setString(keyRawConfig, '');
      await _prefs.setString(keyOrigin, '');
    }
    return loadSavedConfig();
  }

  Future<CmsConfig?> toggleSubscriptionPrivacy(
    String id,
    bool isPrivate,
  ) async {
    final next = [
      for (final s in getSubscriptions())
        if (s.id == id) s.copyWith(isPrivate: isPrivate) else s,
    ];
    await saveSubscriptions(next);
    return loadSavedConfig();
  }

  Future<CmsConfig?> toggleSubscriptionEnabled(String id, bool enabled) async {
    final next = [
      for (final s in getSubscriptions())
        if (s.id == id) s.copyWith(enabled: enabled) else s,
    ];
    await saveSubscriptions(next);
    return loadSavedConfig();
  }

  Future<CmsConfig?> updateSubscriptionGroup(String id, String group) async {
    final cleanGroup = group.trim().isEmpty ? '默认分组' : group.trim();
    final next = [
      for (final s in getSubscriptions())
        if (s.id == id) s.copyWith(group: cleanGroup) else s,
    ];
    await saveSubscriptions(next);
    return loadSavedConfig();
  }

  CmsConfig? loadSavedConfig() {
    final subs = getSubscriptions().where((s) => s.enabled).toList();
    final savedDepots = getSavedDepots();
    if (subs.isNotEmpty) {
      final mergedSites = <CmsSite>[];
      final mergedLives = <LiveSource>[];
      final mergedDepots = <CmsDepot>[...savedDepots];
      final seenDepotUrls = <String>{for (final d in savedDepots) d.url};
      final seenSiteKeys = <String>{};
      String spider = '';

      for (final sub in subs) {
        if (sub.rawContent.trim().isEmpty) continue;
        try {
          final parsed = CmsParser.parseConfig(
            sub.rawContent,
            origin: sub.url,
            defaultGroup: sub.group,
            isPrivate: sub.isPrivate,
            subscriptionId: sub.id,
            defaultName: sub.name,
          );
          if (spider.isEmpty && parsed.spider.isNotEmpty) {
            spider = parsed.spider;
          }
          for (final d in parsed.depots) {
            if (seenDepotUrls.add(d.url)) {
              mergedDepots.add(d);
            }
          }
          for (final site in parsed.sites) {
            var uniqueKey = site.key;
            if (!seenSiteKeys.add(uniqueKey)) {
              uniqueKey = '${site.key}_${sub.id}';
              seenSiteKeys.add(uniqueKey);
            }
            mergedSites.add(
              site.copyWith(
                key: uniqueKey,
                group: site.group.isEmpty ? sub.group : site.group,
                isPrivate: site.isPrivate || sub.isPrivate,
                subscriptionId: sub.id,
              ),
            );
          }
          for (final live in parsed.lives) {
            mergedLives.add(
              live.copyWith(
                group: live.group.isEmpty ? sub.group : live.group,
                isPrivate: live.isPrivate || sub.isPrivate,
                subscriptionId: sub.id,
              ),
            );
          }
        } catch (_) {}
      }
      if (mergedSites.isNotEmpty ||
          mergedLives.isNotEmpty ||
          mergedDepots.isNotEmpty) {
        return CmsConfig(
          sites: mergedSites,
          lives: mergedLives,
          depots: mergedDepots,
          spider: spider,
        );
      }
    }

    final raw = rawConfig;
    if (raw.trim().isEmpty) return null;
    try {
      final parsed = CmsParser.parseConfig(raw, origin: configOrigin);
      if (parsed.depots.isEmpty && savedDepots.isNotEmpty) {
        return CmsConfig(
          sites: parsed.sites,
          lives: parsed.lives,
          depots: savedDepots,
          spider: parsed.spider,
        );
      }
      return parsed;
    } catch (_) {
      return null;
    }
  }
  Future<CmsConfig> saveConfig(
    String rawJson, {
    String origin = '',
    List<CmsDepot>? depots,
    String? activeDepotName,
    String group = '默认分组',
    bool isPrivate = false,
    String customName = '',
  }) async {
    final parsed = CmsParser.parseConfig(
      rawJson,
      origin: origin,
      defaultGroup: group,
      isPrivate: isPrivate,
      defaultName: customName,
    );
    await _prefs.setString(keyRawConfig, rawJson);
    await _prefs.setString(keyOrigin, origin.trim());
    final effectiveDepots = depots ?? parsed.depots;
    if (effectiveDepots.isNotEmpty) {
      await _prefs.setString(
        keyDepots,
        jsonEncode(effectiveDepots.map((d) => d.toJson()).toList()),
      );
    } else if (depots != null && depots.isEmpty) {
      await _prefs.setString(keyDepots, '[]');
    }
    if (activeDepotName != null) {
      await _prefs.setString(keyActiveDepotName, activeDepotName);
    }
    final fmt = CmsParser.detectSubscriptionFormat(rawJson, origin: origin);
    final entryName = customName.trim().isNotEmpty
        ? customName.trim()
        : ((activeDepotName != null && activeDepotName.trim().isNotEmpty)
            ? activeDepotName.trim()
            : (parsed.sites.length == 1
                ? parsed.sites.first.name
                : (origin.trim().isNotEmpty
                    ? (Uri.tryParse(origin.trim())?.host ?? '订阅资源')
                    : '$fmt 订阅')));
    await upsertSubscriptions([
      SubscriptionEntry(
        id: origin.trim().isNotEmpty
            ? 'sub_${origin.trim().hashCode.abs()}'
            : 'sub_primary',
        name: entryName,
        url: origin.trim(),
        group: group.trim().isEmpty ? '默认分组' : group.trim(),
        format: effectiveDepots.isNotEmpty ? '多仓' : fmt,
        isPrivate: isPrivate,
        enabled: true,
        rawContent: rawJson,
        siteCount: parsed.supportedSites.length,
        liveCount: parsed.lives.length,
        updatedAt: DateTime.now().millisecondsSinceEpoch,
      ),
    ]);
    final merged = loadSavedConfig() ??
        CmsConfig(
          sites: parsed.sites,
          lives: parsed.lives,
          depots: effectiveDepots,
          spider: parsed.spider,
        );
    final visibleSites =
        isPrivate ? merged.supportedSites : merged.publicSupportedSites;
    if (visibleSites.isNotEmpty &&
        !visibleSites.any((s) => s.key == selectedSiteKey)) {
      await _prefs.setString(keySelectedSite, visibleSites.first.key);
    } else if (merged.supportedSites.isEmpty && merged.sites.isNotEmpty) {
      await _prefs.setString(keySelectedSite, merged.sites.first.key);
    }
    return merged;
  }
  Future<void> setSelectedSiteKey(String key) async {
    await _prefs.setString(keySelectedSite, key);
  }
  Future<void> setEpisodesDescending(bool value) async {
    await _prefs.setBool(keyEpisodesDescending, value);
  }
  Future<void> setPlaySpeed(double speed) async {
    await _prefs.setDouble(keyPlaySpeed, speed.clamp(0.5, 2.0));
  }
  Future<void> setAutoNext(bool value) async {
    await _prefs.setBool(keyAutoNext, value);
  }
  Future<void> setSkipIntroSec(int seconds) async {
    await _prefs.setInt(keySkipIntroSec, seconds.clamp(0, 600));
  }
  Future<void> setSkipOutroSec(int seconds) async {
    await _prefs.setInt(keySkipOutroSec, seconds.clamp(0, 600));
  }
  Future<void> setRepeatMode(String mode) async {
    await _prefs.setString(keyRepeatMode, mode);
  }
  String getNetdiskCred(String driveKey) {
    switch (driveKey) {
      case 'quark':
        return quarkCookie;
      case 'uc':
        return ucCookie;
      case 'baidu':
        return baiduCookie;
      case 'ali':
        return aliToken;
      default:
        return '';
    }
  }
  bool isNetdiskLoggedIn(String driveKey) {
    return getNetdiskCred(driveKey).trim().isNotEmpty;
  }
  String netdiskCredential(String driveKey) {
    return getNetdiskCred(driveKey);
  }
  Future<void> setNetdiskCredential(String driveKey, String value) {
    return setNetdiskCred(driveKey, value);
  }
  Future<void> setNetdiskCred(String driveKey, String value) async {
    final trimmed = value.trim();
    switch (driveKey) {
      case 'quark':
        await _prefs.setString(keyQuarkCookie, trimmed);
        break;
      case 'uc':
        await _prefs.setString(keyUcCookie, trimmed);
        break;
      case 'baidu':
        await _prefs.setString(keyBaiduCookie, trimmed);
        break;
      case 'ali':
        await _prefs.setString(keyAliToken, trimmed);
        break;
    }
  }
  Future<void> setDriveOrder(List<String> order) async {
    await _prefs.setStringList(keyDriveOrder, order);
  }
  List<WatchHistoryEntry> getWatchHistory() {
    final raw = _prefs.getString(keyWatchHistory) ?? '[]';
    try {
      final list = jsonDecode(raw);
      if (list is! List) return const [];
      return list
          .whereType<Map>()
          .map((m) => WatchHistoryEntry.fromJson(Map<String, dynamic>.from(m)))
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }
  Future<void> upsertWatchHistory(WatchHistoryEntry entry) async {
    final updated = CmsParser.upsertHistory(getWatchHistory(), entry);
    await _prefs.setString(
      keyWatchHistory,
      jsonEncode(updated.map((e) => e.toJson()).toList()),
    );
  }
  Future<void> clearWatchHistory() async {
    await _prefs.setString(keyWatchHistory, '[]');
  }
  List<FavoriteEntry> getFavorites() {
    final raw = _prefs.getString(keyFavorites) ?? '[]';
    try {
      final list = jsonDecode(raw);
      if (list is! List) return const [];
      return list
          .whereType<Map>()
          .map((m) => FavoriteEntry.fromJson(Map<String, dynamic>.from(m)))
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }
  bool isFavorite(String siteKey, String videoId) {
    final target = '$siteKey\n$videoId';
    return getFavorites().any((f) => f.key == target);
  }
  Future<bool> toggleFavorite(CmsSite site, CmsVideo video) async {
    final current = getFavorites().toList();
    final targetKey = '${site.key}\n${video.id}';
    final existingIdx = current.indexWhere((f) => f.key == targetKey);
    bool nowFav;
    if (existingIdx >= 0) {
      current.removeAt(existingIdx);
      nowFav = false;
    } else {
      current.insert(
        0,
        FavoriteEntry(
          site: site.key,
          id: video.id,
          title: video.title,
          poster: video.poster,
          remarks: video.remarks,
          updated: DateTime.now().millisecondsSinceEpoch,
        ),
      );
      if (current.length > CmsParser.maxFavoriteEntries) {
        current.removeRange(CmsParser.maxFavoriteEntries, current.length);
      }
      nowFav = true;
    }
    await _prefs.setString(
      keyFavorites,
      jsonEncode(current.map((e) => e.toJson()).toList()),
    );
    return nowFav;
  }
  List<String> getSearchHistory() {
    final raw = _prefs.getString(keySearchHistory) ?? '[]';
    try {
      final list = jsonDecode(raw);
      if (list is! List) return const [];
      return list.map((e) => e.toString()).where((s) => s.isNotEmpty).toList();
    } catch (_) {
      return const [];
    }
  }
  Future<void> addSearchKeyword(String keyword) async {
    final trimmed = keyword.trim();
    if (trimmed.isEmpty) return;
    final list = getSearchHistory().where((k) => k != trimmed).toList();
    list.insert(0, trimmed);
    if (list.length > 16) list.removeRange(16, list.length);
    await _prefs.setString(keySearchHistory, jsonEncode(list));
  }
  Future<void> clearSearchHistory() async {
    await _prefs.setString(keySearchHistory, '[]');
  }
  /// Exports a backup JSON string compatible with both Android (`MarcoMovie-1`) and Flutter.
  String exportBackupJson() {
    return CmsParser.encodeBackupPayload(
      origin: configOrigin,
      rawConfig: rawConfig,
      settings: <String, dynamic>{
        keySelectedSite: selectedSiteKey,
        keyWatchHistory: _prefs.getString(keyWatchHistory) ?? '[]',
        keyFavorites: _prefs.getString(keyFavorites) ?? '[]',
        keySearchHistory: _prefs.getString(keySearchHistory) ?? '[]',
        keyEpisodesDescending: episodesDescending,
        keyPlaySpeed: playSpeed,
        keyAutoNext: autoNext,
      },
    );
  }
  static String? _normalizeJsonArraySetting(dynamic value) {
    if (value is List) {
      return jsonEncode(value);
    }
    if (value is String) {
      final trimmed = value.trim();
      if (trimmed.isEmpty) return '[]';
      final decoded = jsonDecode(trimmed);
      if (decoded is List) return jsonEncode(decoded);
    }
    return null;
  }
  /// Imports a backup JSON generated by either Android TV/Phone or Windows/Mac/iOS.
  /// Validates all fields before mutating preferences so failed restores preserve existing state.
  Future<CmsConfig?> importBackupJson(String rawBackup) async {
    final decoded = CmsParser.decodeBackupPayload(rawBackup);
    final settings = decoded.settings;
    final nextHistory = settings.containsKey(keyWatchHistory)
        ? _normalizeJsonArraySetting(settings[keyWatchHistory])
        : null;
    final nextFavorites = settings.containsKey(keyFavorites)
        ? _normalizeJsonArraySetting(settings[keyFavorites])
        : null;
    final nextSearch = settings.containsKey(keySearchHistory)
        ? _normalizeJsonArraySetting(settings[keySearchHistory])
        : null;
    CmsConfig? parsedConfig = decoded.parsedConfig;
    if (decoded.rawConfig.isNotEmpty) {
      await _prefs.setString(keyRawConfig, decoded.rawConfig);
      await _prefs.setString(keyOrigin, decoded.origin);
      if (parsedConfig != null &&
          parsedConfig.supportedSites.isNotEmpty &&
          !parsedConfig.supportedSites.any((s) => s.key == selectedSiteKey)) {
        await _prefs.setString(
          keySelectedSite,
          parsedConfig.supportedSites.first.key,
        );
      }
    }
    if (settings[keySelectedSite] is String) {
      await setSelectedSiteKey(settings[keySelectedSite] as String);
    }
    if (nextHistory != null) {
      await _prefs.setString(keyWatchHistory, nextHistory);
    }
    if (nextFavorites != null) {
      await _prefs.setString(keyFavorites, nextFavorites);
    }
    if (nextSearch != null) {
      await _prefs.setString(keySearchHistory, nextSearch);
    }
    if (settings[keyEpisodesDescending] is bool) {
      await setEpisodesDescending(settings[keyEpisodesDescending] as bool);
    }
    if (settings[keyPlaySpeed] is num) {
      final speed = (settings[keyPlaySpeed] as num).toDouble();
      if (speed >= 0.5 && speed <= 2.0) {
        await setPlaySpeed(speed);
      }
    }
    if (settings[keyAutoNext] is bool) {
      await setAutoNext(settings[keyAutoNext] as bool);
    }
    return parsedConfig;
  }
}
