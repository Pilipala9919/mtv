package com.pilipala.marcomovie;

import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

/** Three independent floating regions with one visibility/focus owner. */
final class PlayerChrome {
    final MainActivity a;
    final FrameLayout overlay;
    final LinearLayout dock, progress, heading;
    final LinearLayout loadingPill;
    final TextView loadingText, episodeLabel;
    final StateGlyph state;
    final TextView resolution;
    boolean loading = true;

    PlayerChrome(MainActivity host, Cms.Video video, Cms.Episode episode) {
        a = host;
        overlay = new FrameLayout(a);
        overlay.setTag("player-chrome");
        overlay.setClipChildren(false);
        View topShade = new View(a);
        topShade.setBackground(
                new GradientDrawable(
                        GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[] {0xc4000000, 0x00000000}));
        overlay.addView(topShade, new FrameLayout.LayoutParams(-1, a.dp(160), Gravity.TOP));
        View bottomShade = new View(a);
        bottomShade.setBackground(
                new GradientDrawable(
                        GradientDrawable.Orientation.BOTTOM_TOP,
                        new int[] {0xb8000000, 0x00000000}));
        overlay.addView(bottomShade, new FrameLayout.LayoutParams(-1, a.dp(210), Gravity.BOTTOM));
        heading = a.vertical();
        heading.setTag("player-heading");
        if (!a.isTvDevice()) {
            LinearLayout topActions = a.row();
            topActions.setPadding(0, 0, 0, a.dp(8));
            Button backBtn = a.navButton("‹ 返回", "player-back", a::leavePlayback);
            backBtn.setTextColor(MainActivity.WHITE);
            backBtn.setBackground(a.bg(0x44000000, 16));
            topActions.addView(backBtn, new LinearLayout.LayoutParams(-2, a.dp(34)));
            View spacer = new View(a);
            topActions.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1));
            Button rotateBtn = a.navButton("旋转屏幕", "player-rotate", a::togglePlayerOrientation);
            rotateBtn.setTextColor(MainActivity.WHITE);
            rotateBtn.setBackground(a.bg(0x44000000, 16));
            topActions.addView(rotateBtn, new LinearLayout.LayoutParams(-2, a.dp(34)));
            heading.addView(topActions, new LinearLayout.LayoutParams(-1, -2));
        }
        TextView title = a.text(video.title, a.isPortrait() ? 20 : 26, MainActivity.WHITE);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.getPaint().setFakeBoldText(true);
        title.setSingleLine();
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setShadowLayer(a.dp(4), 0, a.dp(2), 0xdd000000);
        heading.addView(title);
        String line = a.activeLine == null ? "" : a.activeLine.name;
        episodeLabel =
                a.text(episode.name + (line.isEmpty() ? "" : "  ·  " + line), 14, 0xffdddddf);
        episodeLabel.setTag("player-episode");
        episodeLabel.setSingleLine();
        episodeLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        episodeLabel.setPadding(0, a.dp(6), 0, 0);
        heading.addView(episodeLabel);
        resolution = a.text("分辨率读取中", 12, 0xffdddddf);
        resolution.setTag("player-resolution");
        resolution.setPadding(0, a.dp(6), 0, 0);
        heading.addView(resolution);
        a.playStatus = a.text("正在加载所选剧集…", 12, MainActivity.MUTED);
        a.playStatus.setPadding(0, a.dp(6), 0, 0);
        heading.addView(a.playStatus);
        FrameLayout.LayoutParams top = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        int sideMargin = a.isPortrait() ? a.dp(20) : a.dp(44);
        top.setMargins(sideMargin, a.dp(24), sideMargin, 0);
        overlay.addView(heading, top);

        progress = a.vertical();
        progress.setTag("player-progress");
        a.playClock = a.text("--:-- / --:--", 12, MainActivity.WHITE);
        a.playClock.setGravity(Gravity.RIGHT);
        a.playClock.setPadding(0, 0, a.dp(12), 0);
        progress.addView(a.playClock);
        int width = a.windowWidth();
        FrameLayout.LayoutParams track =
                new FrameLayout.LayoutParams(
                        Math.min(a.dp(760), Math.max(a.dp(220), width - a.dp(48))),
                        -2,
                        Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        track.bottomMargin = a.dp(94);
        overlay.addView(progress, track);

        dock = a.vertical();
        dock.setTag("player-dock");
        dock.setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5));
        dock.setClipChildren(false);
        GradientDrawable glass = a.bg(0xed262629, 30);
        glass.setStroke(a.dp(1), 0x30ffffff);
        dock.setBackground(glass);
        dock.setElevation(a.dp(10));
        FrameLayout.LayoutParams bottom =
                new FrameLayout.LayoutParams(
                        Math.min(a.dp(552), Math.max(a.dp(240), width - a.dp(32))),
                        -2,
                        Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bottom.bottomMargin = a.dp(16);
        overlay.addView(dock, bottom);

        state = new StateGlyph();
        state.setTag("player-state");
        state.setFocusable(false);
        state.setVisibility(View.GONE);
        state.setOnClickListener(
                v -> {
                    a.togglePlayback();
                    a.showControls(true);
                });
        overlay.addView(state, new FrameLayout.LayoutParams(a.dp(72), a.dp(72), Gravity.CENTER));
        a.playbackLayer.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        loadingPill = a.row();
        loadingPill.setTag("player-loading");
        loadingPill.setGravity(Gravity.CENTER_VERTICAL);
        loadingPill.setPadding(a.dp(24), a.dp(16), a.dp(24), a.dp(16));
        GradientDrawable loadingBg = a.bg(0xf022232a, 24);
        loadingBg.setStroke(a.dp(1), 0x26ffffff);
        loadingPill.setBackground(loadingBg);
        loadingPill.setElevation(a.dp(10));
        loadingPill.addView(
                new PlaybackLoading.Ring(a), new LinearLayout.LayoutParams(a.dp(26), a.dp(26)));
        String epTitle =
                episode != null && episode.name != null && !episode.name.isEmpty()
                        ? " " + episode.name
                        : "";
        loadingText = a.text("正在加载" + epTitle + "…", 14, MainActivity.WHITE);
        loadingText.setPadding(a.dp(14), 0, 0, 0);
        loadingPill.addView(loadingText);
        a.playbackLayer.addView(loadingPill, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        a.playerOverlay = overlay;
        a.controlsVisible = true;
    }

    void relayout() {
        int width = a.windowWidth();
        ViewGroup.LayoutParams p = progress.getLayoutParams();
        if (p != null) {
            p.width = Math.min(a.dp(760), Math.max(a.dp(220), width - a.dp(48)));
            progress.setLayoutParams(p);
        }
        ViewGroup.LayoutParams d = dock.getLayoutParams();
        if (d != null) {
            d.width = Math.min(a.dp(552), Math.max(a.dp(240), width - a.dp(32)));
            dock.setLayoutParams(d);
        }
    }

    void resolution(int width, int height) {
        resolution.setText(width > 0 && height > 0 ? width + " × " + height : "分辨率未知");
    }

    void setLoading(boolean value) {
        loading = value;
        update();
    }

    void switchEpisode(Cms.Episode episode, Cms.Line line) {
        String lineName = line == null || line.name == null ? "" : line.name;
        String epName = episode == null || episode.name == null ? "" : episode.name;
        episodeLabel.setText(epName + (lineName.isEmpty() ? "" : "  ·  " + lineName));
        resolution.setText("分辨率读取中");
        String statusMsg = "正在加载" + (epName.isEmpty() ? "" : " " + epName) + "…";
        if (a.playStatus != null) a.playStatus.setText(statusMsg);
        loadingText.setText(statusMsg);
        loading = true;
        update();
    }

    void update() {
        if (a.prepared) loading = false;
        if (a.player != null && a.prepared) resolution.setText(a.player.videoResolution());
        boolean showSpinner = loading && !a.prepared && a.playbackLoading == null && !a.miniMode;
        loadingPill.setVisibility(showSpinner ? View.VISIBLE : View.GONE);
        state.setVisibility(showSpinner ? View.GONE : View.VISIBLE);
        state.setContentDescription(!a.prepared ? "正在准备" : a.playing ? "正在播放，确认暂停" : "已暂停，确认继续");
        state.invalidate();
    }

    final class StateGlyph extends View {
        final Paint paint = new Paint(3);

        StateGlyph() {
            super(a);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            paint.setColor(0x99303034);
            canvas.drawCircle(cx, cy, getWidth() / 2f, paint);
            paint.setColor(MainActivity.WHITE);
            if (!a.prepared) {
                paint.setStrokeWidth(a.dp(3));
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(cx, cy, a.dp(12), paint);
                paint.setStyle(Paint.Style.FILL);
                return;
            }
            if (a.playing) {
                canvas.drawRoundRect(
                        cx - a.dp(10),
                        cy - a.dp(13),
                        cx - a.dp(3),
                        cy + a.dp(13),
                        a.dp(2),
                        a.dp(2),
                        paint);
                canvas.drawRoundRect(
                        cx + a.dp(3),
                        cy - a.dp(13),
                        cx + a.dp(10),
                        cy + a.dp(13),
                        a.dp(2),
                        a.dp(2),
                        paint);
            } else {
                Path p = new Path();
                p.moveTo(cx - a.dp(8), cy - a.dp(14));
                p.lineTo(cx + a.dp(15), cy);
                p.lineTo(cx - a.dp(8), cy + a.dp(14));
                p.close();
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setStrokeWidth(a.dp(3));
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                canvas.drawPath(p, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
    }
}
